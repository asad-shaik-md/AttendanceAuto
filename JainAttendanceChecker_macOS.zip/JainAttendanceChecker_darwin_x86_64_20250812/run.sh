#!/bin/bash
echo "Starting Jain University Attendance Checker (Intel macOS)..."
echo "=========================================================="

# Make executable if needed
chmod +x ./JainAttendanceChecker

# Run the application
./JainAttendanceChecker

echo "Program finished. Press Enter to close..."
read
